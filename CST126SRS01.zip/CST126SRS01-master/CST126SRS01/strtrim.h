#ifndef _STRTRIM_H_
#define _STRTRIM_H_

char* strtrim(char str[]);

#endif
