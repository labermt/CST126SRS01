/***********************************************************
* Class ID:			Mespirit
* Date Created:		1/19/18
* Updated:			1/20/18
* Assignment:		CST126SRS01
* Filename:			strtrm.cpp
* Overview:			Trim all white space from front and back
*					ends of given strings.
* Issues:			Throws an error at line 71 in main.cpp.
*					haven't been able to resolve the issue with
*					assert(). Not sure if the problem is with my 
*					strtrim function or something else.
***********************************************************/
#include "stdafx.h"
#include <cstring>
#include <cctype>
#include "strtrim.h"

char * strtrim(char str[])
{
	char * const result = str; //auto can replace char * const

	if (str != nullptr)
	{
		int i = 0, front_c = 0, back_c = 0;
		char ch = '0';
		bool w_space = true;

		size_t len = strlen(result), trimmed_str_len = 0; //gets length of str 

		while (ch != '\0' && w_space == true) //checks for \0 and whitespace loops until either is found
		{
			ch = result[i]; //sets ch to element in array slot i 

			if (isspace(ch)) //checks if ch == whitespace
			{
				front_c++; //increments log for front whitespace count 
				i++; //moves to next element in array slot i
			}
			else
				w_space = false; //if ch != whitespace; ends loop
		}

		while (w_space == true)
		{
			ch = result[len - i]; //sets ch to element in array slot len - i

			if (isspace(ch)) //checks if ch == whitespace
			{
				back_c++; //increments log for back whitespace count
				i++; //moves to next element in array slot len - i
			}
			else
				w_space = false; //if ch != whitespace; ends loop
		}

		trimmed_str_len = len - (front_c + back_c); //determines lenth of string not including front end and back end whitespace

		memmove(result, result + front_c, trimmed_str_len); //grabs the string starting past the end of front w_space

		memmove(result + trimmed_str_len + 1, result + len + 1, 1); //grabs \0 and moves it to end of result
	}
	
	return result;
}